#include "drawable.h"

Drawable::Drawable(){}
Drawable::~Drawable(){}

void Drawable::Bind(){}
void Drawable::Unbind(){}
void Drawable::Draw(){}
